
# Marketo.

<p style="text-align: justify;"  align="center">Create a complete responsive digital marketing / seo marketing / web design / online service providor website using HTML,CSS and a little touch of JavaScript.</p>



<p style="font-size:50rem;" align="center" padding-top: 10px; >Full Web Page</p>

![FireShot Capture 001 - Marketo  - hrsshopnil github io](https://user-images.githubusercontent.com/89196977/135708132-dc63d201-fb99-45ba-97f1-bdd6b96507df.png)

<p style="text-align: justify;" align="center">The main feature of this website are:
  
 ✔ responsive header section using flexbox.
  
✔ responsive home section using flexbox.
  
✔ responsive service box section using css grid.
  
✔ responsive about section using flexbox.
  
✔ responsive portfolio image gallery section using css grid.
  
✔ responsive pricing table section using css grid.
  
✔ responsive review section using css grid.
  
✔ responsive contact form section using flexbox.
  
✔ responsive footer section using css grid.</p>
